s = "Qual o seu nome?"
puts s
r = gets
s2 = "Qual a sua idade?"
puts s2
r2 = gets.to_i
puts "Seu nome é: \n" + r
puts "Sua idade é " + r2.to_s

if r2 > 18
  puts "Você já é maior de idade + 1!"
elsif r2 == 18
  puts "Você acabou de ficar maior de idade!"
else
  puts "Você é menor de idade!"
end

case r2
when 0 .. 2
  puts "bb"
when 3 .. 12
  puts "Criança"
when 13 .. 17
  puts "Adolescente"
when 18 .. 59
  puts "Adulto"
else
  puts "Idoso"
end

sexo ='M'

sexo == 'M' ? (puts 'Masc') : (puts 'Fem')