#i = 0
#num = 5

#while i < num do
#  print i
#  i+=1
#end

v = [0,1,2,3,4,5]
v.push(6)
#v.each do |i|
#  puts i
#end
puts "--------------"
for x in 0..6 do
  puts v.pop
end
puts "xxxxxxxxxxxxxxxxx"
puts v

hash = {"a" => 1, "b" => "z"}
puts hash["a"]