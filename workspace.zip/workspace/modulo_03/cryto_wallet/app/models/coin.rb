class Coin < ApplicationRecord
end
